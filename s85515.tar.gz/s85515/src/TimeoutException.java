public class TimeoutException extends Exception {
  public TimeoutException() {
    super();
  }

public TimeoutException(String e) {
  super(e);
}
}
